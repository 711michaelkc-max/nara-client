const https = require('https');

// --- 설정 정보 (Configuration) ---
// 1. API 접속 주소 (Endpoint)
const ENDPOINT = "https://apis.data.go.kr/1230000/BidPublicInfoService04/getBidPblancListInfoCnstVk";

// 2. 인증키 (Service Key - Raw)
const SERVICE_KEY = "4d03d6d8d9dd48b0fad3d09a9fee0c061e460c231eb630e836ee599c5634650a";

// 3. 요청 파라미터 (Query Parameters)
// 스크린샷과 동일한 파라미터 구성
const params = {
    "numOfRows": "10",
    "pageNo": "1",
    "inqryDiv": "1",
    "inqryBgnDt": "202001010000",
    "inqryEndDt": "202001302359",
    "type": "json",
    "bidNtceNo": "20200100008",
    "ServiceKey": encodeURIComponent(SERVICE_KEY) // URL Standard Encoding
};

// 쿼리 스트링 조립
const queryString = Object.keys(params)
    .map(key => `${key}=${params[key]}`)
    .join('&');

const fullUrl = `${ENDPOINT}?${queryString}`;

console.log("============================================");
console.log("   [API 요청 상세 정보]");
console.log("============================================");
console.log(`URL: ${fullUrl}`);
console.log("--------------------------------------------");

// HTTPS 요청 전송
const req = https.get(fullUrl, {
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'application/json, text/plain, */*'
    }
}, (res) => {
    let data = '';

    console.log(`[응답 상태 코드]: ${res.statusCode} ${res.statusMessage}`);
    console.log("--------------------------------------------");

    // 데이터 수신
    res.on('data', (chunk) => {
        data += chunk;
    });

    // 수신 완료 후 출력
    res.on('end', () => {
        console.log("[응답 데이터]:");
        try {
            // JSON 포매팅 시도
            const parsed = JSON.parse(data);
            console.log(JSON.stringify(parsed, null, 2));
        } catch (e) {
            // HTML/Text일 경우 그대로 출력
            console.log(data);
        }
    });
});

req.on('error', (e) => {
    console.error(`[요청 에러]: ${e.message}`);
});
